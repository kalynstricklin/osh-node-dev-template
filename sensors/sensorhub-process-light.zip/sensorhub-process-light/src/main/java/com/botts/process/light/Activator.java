/***************************** BEGIN LICENSE BLOCK ***************************

 Copyright (C) 2022 Botts Innovative Research, Inc. All Rights Reserved.
 ******************************* END LICENSE BLOCK ***************************/
package com.botts.process.light;

import org.sensorhub.utils.OshBundleActivator;

/**
 * @author Nick Garay
 * @since Jan. 7, 2022
 */
public class Activator extends OshBundleActivator {
}
