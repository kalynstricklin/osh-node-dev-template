# FlightAware Add-on

Add-on to ingest real-time flight plan and position data from FlightAware Firehose feed
