# Navigation Database Add-on

Add-on to read navigation data from an ARINC-424 compatible database file.

