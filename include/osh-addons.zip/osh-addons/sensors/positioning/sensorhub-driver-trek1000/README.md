### DecaWave TREK1000 Positioning System

OSH sensor adaptor for DecaWave's Ultra-Wide Band positioning system model TREK1000.
