### XSens MTi Inertial Measurement Unit (IMU)

Sensor adaptor for the XSens MTi IMU providing raw measurements of acceleration, angular velocity and magnetic field direction, as well as fused absolute orientation. Communication is through a serial interface.
