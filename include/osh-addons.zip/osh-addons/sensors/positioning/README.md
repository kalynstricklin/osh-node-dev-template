# OSH for Positioning

This folder contains various add-on modules for geolocation and positioning.

This includes drivers for sensors such as IMUs, GPS, etc. but also processing modules for computing location and orientation.
