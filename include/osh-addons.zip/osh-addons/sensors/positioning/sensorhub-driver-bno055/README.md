### Adafruit BNO55 Inertial Measurement Unit (IMU)

OSH adaptor for Adafruit BNO55 sensor shield providing rotations about a East-North-Up reference frame. Communication is through a serial interface.
