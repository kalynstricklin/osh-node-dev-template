### GPS using NMEA protocol

OSH sensor adaptor supporting any GPS unit outputting data in the NMEA standard through a serial interface.
