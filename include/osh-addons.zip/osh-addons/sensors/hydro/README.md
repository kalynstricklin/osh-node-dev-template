# OSH for Hydrology

This folder contains various add-on modules for hydrology applications and water in general (e.g. water quality, surface waters, water management systems, etc.)
