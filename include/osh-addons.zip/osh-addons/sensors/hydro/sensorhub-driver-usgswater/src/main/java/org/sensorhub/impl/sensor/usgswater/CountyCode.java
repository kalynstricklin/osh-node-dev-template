package org.sensorhub.impl.sensor.usgswater;

public class CountyCode {
	
	public String territory;
	public String countyCode;
	public String name;
	
	public String getTerritory() {return territory;}
	public void setTerritory(String territory) {this.territory = territory;}
	
	public String getCountyCode() {return countyCode;}
	public void setCountyCode(String countyCode) {this.countyCode = countyCode;}
	
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
}
