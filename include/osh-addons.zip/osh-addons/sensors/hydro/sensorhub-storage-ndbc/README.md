### NDBC Buoy Data Archive

This module implements the storage API and connects to NDBC web archive for buoy data. It retrieves observations on-demand using NDBC web service.

Site information is retrieved using the **NDBC Site Web Service** documented [here](http://sdf.ndbc.noaa.gov/sos/).

This is currently non-functional, as the driver is currently being developed.
