### Angel Sensor Health Monitor

OSH adaptor for the Angel Sensor health monitoring wrist band. Communication is done through Bluetooth LE.
