### AVL Intergraph 911

OSH sensor adaptor for Automated Vehicle Location (AVL) coming from mobile vehicles using the Intergraph 911 system protocol. Supports automatic tracking of responder vehicles such as fire, police, ambulance, and utility vehicles. Includes time-based location plus status.
