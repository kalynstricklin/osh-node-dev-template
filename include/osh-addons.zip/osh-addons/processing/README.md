### OSH Processing Add-ons

This folder contains add-on modules for processing, including algorithms themselves and often their SensorML process counterpart.
