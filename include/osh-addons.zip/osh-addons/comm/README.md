# OSH Communication Drivers

This folder contains source code for communication related modules (e.g. Bluetooth, USB, serial, etc..)

These modules are typically used by sensor drivers that need to communicate data via one or more physical layer and transport.
