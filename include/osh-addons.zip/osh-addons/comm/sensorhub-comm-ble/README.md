#### Bluetooth LE Communication Support

Common Bluetooth LE API that should be used by sensor drivers.

This should be implemented by platform specific Bluetooth LE stacks (e.g. Android, BlueZ on Linux, etc...)

