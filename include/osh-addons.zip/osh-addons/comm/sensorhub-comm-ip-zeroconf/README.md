#### IP Networks and ZeroConf Communication Support
Support for multiple IP networks + ZeroConf discovery using the JmDNS library
