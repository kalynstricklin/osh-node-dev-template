### JDK Device I/O Communication support
OSH adaptor supporting serial and I2C communication using JDK
