#### Bluetooth LE Communication Support
Bluetooth network provider based on BlueZ D-Bus API.

On Ubuntu, you first need to install the libdbus-java package

