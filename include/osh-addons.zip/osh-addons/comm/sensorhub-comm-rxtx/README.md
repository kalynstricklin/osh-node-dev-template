#### Serial RX/TX Communication Support
Serial communication provider based on the RX/TX library
