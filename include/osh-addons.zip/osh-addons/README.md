### OpenSensorHub Add-ons

This repository contains various OpenSensorHub add-on modules including sensor drivers, database connectors, processing algorithms, additional services, etc.

Please clone this repository with the `--recursive` option (`git clone --recursive`) as it contains submodules.

For more information about OpenSensorHub, see the [OSH Core Readme](https://github.com/opensensorhub/osh-core).
